<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		$bio = array(
				'nama' => "Aldy Destianto  Wibowo" ,
				'nim' => "1541180136" ,
				'alamat' => "Jalan Cendrawasih BY 21 Wisma Tropodo Waru Sidoarjo" ,
				'no_tlpn' => "085733484739" ,
				);
		$this->load->view('about', $bio);
	}

}

/* End of file H ome.php */
/* Location: ./application/controllers/Home.php */
